# Development Notes

This document records the key architectural decisions and recent fixes
for the Fallout 4 Tutorial Helper add-on.  It serves as a memorization aid
so future changes don't accidentally reintroduce bugs or regressions.

## Policy Violation Fix (Feb 2026)

- Blender issued warnings about `policy violation with top level module`
  when the add-on was enabled.  Investigation showed the warnings were
  triggered by embedded third-party helpers (UE4 importer, UModel Tools,
  AssetStudio, AssetRipper, etc.) which performed heavy work at import time.

- **Resolution:**
  1. Removed external helper modules from the top-level `modules` list in
     `__init__.py` and from the initial import section.
  2. Modified `_post_register()` to only *query* status of those helpers,
     never to register or load them unless the user explicitly requests it.
  3. Added a new preference `auto_register_tools` (default `False`) to
     optionally restore the original auto-download/registration behaviour.
  4. Updated preference UI and documentation accordingly.

- Result: enabling the add-on no longer produces policy warnings; external
  integrations only load on demand.

## Mossy Link Integration

- `mossy_link.py` implements a small TCP JSON server that the external
  *Mossy* application can use to control Blender.

- Key components:
  * `MossyLinkServer` class with handlers for `status`, `script`, `text`,
    `get_object`, and `run_operator` commands.
  * `_get_prefs()` helper returns the add-on preferences (port/token/autostart).
  * `send_to_mossy()` client helper for scripts or external processes.
  * An operator (`WM_OT_MossyLinkToggle`) and panel in the 3D-view sidebar
    that allow the user to start/stop the server and show connection state.
  * Preferences (ported into `FO4AddonPreferences`) for port, token,
    and autostart behaviour.

- Server startup/shutdown is handled in `register()`/`unregister()`;
  tests have been performed using a simulated `bpy` environment outside of
  Blender (see notes above).  The module is self-contained and may be
  imported independently for unit testing.

- **Historical quirk:** older versions stored the server on the current
  `Scene` datablock.  As a result a fresh mesh import or opening a blank
  file would break the connection and users had to manually click the
  panel’s “Disconnect / Connect to Mossy” button before the external app
  would talk to Blender again.  The server is now kept at module scope and
  a `load_post` handler automatically restarts it, so the connection
  survives new scenes; the helper UI still offers a manual toggle for
  debugging.

## Notes for Future Work

- When adding new external integrations, consult this document first to
  avoid reintroducing top-level imports.  New heavy helpers should follow
  the lazy-load pattern used above.

- Any extension to the Mossy protocol should add new `_handle_*` methods
  in `MossyLinkServer` and update the client helper accordingly.

- Keep the preference lookup (`_get_prefs()`) consistent across modules to
  avoid duplicated logic.

- Remember to stop the mossy server thread in `unregister()` and when
  toggling off; the current implementation handles this correctly but
  modifications may break it.

- This file should be updated whenever similar platform-specific workarounds
  or new high-level features are introduced.

## Advanced Weighting Features (Mar 2026)

- Vegetation artists were repeatedly hand‑painting "vortex" or "vortex weight"
  channels for plants and trees so that Fallout 4’s wind system could bend
  leaves/branches.  The add-on now provides three automatic helpers:
  * `AnimationHelpers.generate_wind_weights()` / **Generate Wind Weights**
    operator – computes a simple linear falloff along a chosen axis and stores
    it in a vertex group (default name "Wind").  Works on arbitrary meshes and
    requires no manual painting.
  * `AnimationHelpers.apply_wind_animation()` / **Apply Wind Animation**
    operator – one click to create a minimal armature with a "Wind" bone and
    a looping noise‑driven rotation action.  Play the timeline to see the
    mesh sway; the resulting animation is exported for FO4.
  * `AnimationHelpers.auto_weight_paint()` / **Auto Weight Paint** operator –
    skins a mesh to an FO4 armature.  By default it uses Blender’s
    `ARMATURE_AUTO` parent operation, but if the `libigl` Python package is
    installed (the operator will attempt to `pip install` it automatically)
    it instead computes bounded biharmonic weights (BBW) for cleaner
    deformations.  This brings the add-on in line with the latest community
    workflows and removes the need for external tools or manual weight
    painting.

- Both operators are accessible via the **Animation Helpers** sidebar panel
  and are fully scriptable.  They have been tested on Blender 3.6–5.0 and
  correctly handle missing dependencies by falling back to built-in behaviour.

- **Mesh optimization issue:** the previous `Optimize Mesh` routine could
  collapse vertices across UV seams and corrupt textures when the user
  reported "eating" of texture.  The function has been rewritten to use a
  UV-aware bmesh remove‑doubles operation; textures are now preserved after
  optimization.  Additionally, the operation is now driven by preferences
  (threshold, UV preservation toggle, apply transforms flag) under the
  "Mesh Optimization" section in the add-on settings so users may fine-tune
  behaviour for their assets.  The optimizer button also exposes these
  options directly via a popup for per-object overrides.

- When modifying or extending these helpers later, remember:
  * weight computation should always be deterministic and not rely on external
    network resources except for optional `pip` installs;
  * keep the panel buttons and API methods in sync to avoid UX drift;
  * update `API_REFERENCE.md`, `CHANGELOG.md` and `RIGGING_AND_MOTION_INTEGRATION.md`
    when changes are made (this file tracks the rationale).
  * if new batch or preset functionality is added, consider expanding the
    smoke-test script so CI exercises the new operators automatically.

## Other recent improvements

- Added batch processing operators for wind weights, wind animation and
  auto-weight painting; these are exposed in the UI and allow multi-selection
  workflows.
- Wind animation operator now supports built-in presets (Grass, Shrub, Tree)
  for one-click styling.
- Added **Toggle Wind Preview** operator and handler; can be toggled from the
  panel to see a live swaying effect without playing the timeline.
- `tools/check_blenders.py` was extended to instantiate a test mesh, run the
  new operators (including batch and preview toggle) and verify they complete
  without error, ensuring CI catches regressions in automation logic.
- Automatic dependency installation will prefer local wheel files placed in
  `tools/`, enabling offline setups.

## Blender Version Smoke‑Testing

- To help ensure compatibility across the many Blender releases we support,
  a helper script has been added at `tools/check_blenders.py`.

  Usage example:

  ```powershell
  python tools/check_blenders.py \
      "C:\Program Files\Blender Foundation\Blender 2.93\blender.exe" \
      "C:\Program Files\Blender Foundation\Blender 3.6\blender.exe" \
      "C:\Program Files\Blender Foundation\Blender 5.0\blender.exe"
  ```

  The script will launch each specified executable in background mode, import
  the add-on, register it, and report whether the operation succeeded.  Any
  exceptions are printed to the console along with the version string.  The
  exit status is zero only if *all* builds passed.

- This makes it easy for developers and automated CI jobs to verify that a
  single ZIP build works on every tested Blender version (2.80‑4.x‑5.x).
  There is no need to produce separate zip files per version: the same
  package is used everywhere.
